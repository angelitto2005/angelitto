import hashlib
import sys
import json

import requests  # Changed from httpx to requests
import re  # Changed from regex to re

headers = {
    "User-Agent": "curl/8.16.0"
}

# Changed from httpx.Client to requests.Session
client = requests.Session()
client.headers.update(headers)

API_URL = "https://dec.eatmynerds.live"

def solve_challenge(challenge_response):
    """Solve the POW challenge"""
    try:
        payload = re.search(r'"payload":"([^"]*)"', challenge_response).group(1)
        signature = re.search(r'"signature":"([^"]*)"', challenge_response).group(1)
        difficulty = int(re.search(r'"difficulty":([0-9]*)', challenge_response).group(1))
        
        challenge = payload.split('.')[0]
        prefix = '0' * difficulty
        
        nonce = 0
        while True:
            text_to_hash = f"{challenge}{nonce}"
            hash_val = hashlib.sha256(text_to_hash.encode()).hexdigest()
            
            if hash_val.startswith(prefix):
                break
            nonce += 1
        
        return payload, signature, nonce
    except Exception as e:
        print(f"Error solving challenge: {e}", file=sys.stderr)
        return None, None, None

def decrypt_stream_url(embed_link, quality=None, subs_language="english"):
    try:
        # Get challenge
        challenge_response = client.get(f"{API_URL}/challenge", timeout=10)
        
        if not challenge_response.text:
            print("ERROR: Failed to get challenge response", file=sys.stderr)
            return embed_link, []  # Return original URL if decryption fails
        
        payload, signature, nonce = solve_challenge(challenge_response.text)
        
        if payload is None:
            print("ERROR: Failed to solve challenge", file=sys.stderr)
            return embed_link, []  # Return original URL if decryption fails
        
        print(f"Challenge solved - nonce: {nonce}", file=sys.stderr)
        
        params = {
            "url": embed_link,
            "payload": payload,
            "signature": signature,
            "nonce": nonce
        }
        
        response = client.get(API_URL, params=params, timeout=10)
        
        if response.status_code != 200:
            print(f"ERROR: {response.text}", file=sys.stderr)
            # If API returns error, return original URL as fallback
            return embed_link, []
        
        try:
            json_data = response.json()
        except json.JSONDecodeError as e:
            print(f"ERROR: Failed to parse JSON: {e}", file=sys.stderr)
            print(f"Response was: {response.text}", file=sys.stderr)
            # Return original URL if JSON parsing fails
            return embed_link, []
        
        video_link = None
        if 'sources' in json_data:
            for source in json_data['sources']:
                if 'file' in source and '.m3u8' in source['file']:
                    video_link = source['file']
                    break
        
        if video_link and quality:
            video_link = re.sub(r'/playlist\.m3u8', f'/{quality}/index.m3u8', video_link)
        
        subs_links = []
        if 'tracks' in json_data:
            for track in json_data['tracks']:
                if 'file' in track and 'label' in track:
                    if re.search(rf'{subs_language}', track['label'], re.IGNORECASE):
                        subs_links.append(track['file'])

        # If we successfully got a decrypted URL, return it; otherwise return original
        if video_link:
            return video_link, subs_links
        else:
            print("WARNING: Could not find decrypted video link, using original", file=sys.stderr)
            return embed_link, []
            
    except requests.exceptions.RequestException as e:
        print(f"Network error during decryption: {e}", file=sys.stderr)
        # Return original URL if network request fails
        return embed_link, []
    except Exception as e:
        print(f"Unexpected error during decryption: {e}", file=sys.stderr)
        # Return original URL for any other errors
        return embed_link, []