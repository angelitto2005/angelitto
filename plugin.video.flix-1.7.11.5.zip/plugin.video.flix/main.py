import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
from urllib.parse import urlsplit, parse_qs

# Add the flix_cli module to the Python path
if __name__ == '__main__':
    import xbmcaddon
    import xbmcvfs
    
    # Get addon path
    addon = xbmcaddon.Addon()
    addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))
    
    # Add the lib directory to the Python path
    lib_path = xbmcvfs.translatePath('special://home/addons/plugin.video.flix/lib')
    if lib_path not in sys.path:
        sys.path.insert(0, lib_path)
    
    # Import our modules from the flix_cli package
    try:
        from flix_cli.core.__flix_cli__ import parse_episode_range, get_tv_seasons, get_season_episodes, get_episode_servers, get_embed_link
        from flix_cli.core.utils.__decryptor__ import decrypt_stream_url
        from flix_cli.core.utils.__config__ import get_config
    except ImportError as e:
        xbmc.log(f'FlixHQ: Import error - {str(e)}', xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Import Error', f'Failed to import required modules: {str(e)}')
        sys.exit(1)

    # Get the plugin handle
    handle = int(sys.argv[1])
    
    # Get the requested URL
    addon_url = sys.argv[0]
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    
    # Extract action and other parameters
    action = params.get('action', 'main_menu')
    query = params.get('query', '')
    url = params.get('url', '')
    content_type = params.get('content_type', '')
    media_id = params.get('media_id', '')
    season = params.get('season', '')
    episode = params.get('episode', '')
    episode_id = params.get('episode_id', '')
    series_url = params.get('series_url', '')
    season_id = params.get('season_id', '')
    page = params.get('page', '1')


    def add_dir(name, url, icon_image="DefaultVideo.png", is_folder=True, info_labels=None):
        """Add a directory item to the Kodi interface"""
        if info_labels is None:
            info_labels = {"Title": name}
            
        list_item = xbmcgui.ListItem(label=name)
        list_item.setInfo(type="Video", infoLabels=info_labels)
        list_item.setArt({'icon': icon_image, 'thumb': icon_image})
        
        if not is_folder:
            list_item.setProperty('IsPlayable', 'true')
        
        return xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=is_folder)


    def main_menu():
        """Main menu for the plugin"""
        # Search for content
        search_url = f'{addon_url}?action=search'
        add_dir('Search Movies/TV Shows', search_url, icon_image='DefaultAddonVideo.png')
        
        # Trending menu
        trending_url = f'{addon_url}?action=trending_menu'
        add_dir('Trending', trending_url, icon_image='DefaultAddonVideo.png')
        
        # Latest menu
        latest_url = f'{addon_url}?action=latest_menu'
        add_dir('Latest', latest_url, icon_image='DefaultAddonVideo.png')
        
        # Movies menu
        movies_url = f'{addon_url}?action=movies_menu&page=1'
        add_dir('Movies', movies_url, icon_image='DefaultAddonVideo.png')
        
        # TV Shows menu
        tvshows_url = f'{addon_url}?action=tvshows_menu&page=1'
        add_dir('TV Shows', tvshows_url, icon_image='DefaultAddonVideo.png')
        
        # Genres menu
        genres_url = f'{addon_url}?action=genres_menu'
        add_dir('Genres', genres_url, icon_image='DefaultAddonVideo.png')
        
        # Countries menu
        countries_url = f'{addon_url}?action=countries_menu'
        add_dir('Countries', countries_url, icon_image='DefaultAddonVideo.png')
        
        xbmcplugin.endOfDirectory(handle)


    def trending_menu():
        """Trending menu with two submenus"""
        # Trending Movies
        trending_movies_url = f'{addon_url}?action=trending_movies'
        add_dir('Trending Movies', trending_movies_url, icon_image='DefaultAddonVideo.png')
        
        # Trending TV Shows
        trending_series_url = f'{addon_url}?action=trending_series'
        add_dir('Trending TV Shows', trending_series_url, icon_image='DefaultAddonVideo.png')
        
        xbmcplugin.endOfDirectory(handle)


    def latest_menu():
        """Latest menu with two submenus - based on actual HTML structure from code.txt"""
        # Latest Movies
        latest_movies_url = f'{addon_url}?action=latest_movies'
        add_dir('Latest Movies', latest_movies_url, icon_image='DefaultAddonVideo.png')
        
        # Latest TV Shows
        latest_series_url = f'{addon_url}?action=latest_series'
        add_dir('Latest TV Shows', latest_series_url, icon_image='DefaultAddonVideo.png')
        
        xbmcplugin.endOfDirectory(handle)


    def get_trending_movies():
        """Fetch trending movies from the home page - using actual HTML structure from code.txt"""
        import requests
        from bs4 import BeautifulSoup
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the home page
            response = client.get("https://flixhq.to/home")
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find the trending movies section based on the actual HTML structure from code.txt
            trending_movies_div = soup.find('div', id='trending-movies')
            
            if not trending_movies_div:
                xbmc.log('FlixHQ: Trending movies section not found', xbmc.LOGERROR)
                return []
            
            # Find all movie items in the trending movies section based on the actual structure
            movie_items = trending_movies_div.find_all('div', class_='flw-item')
            
            movies = []
            for item in movie_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract movie details based on the actual HTML structure from code.txt
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h3', class_='film-name')  # h3 tag as per code.txt
                    year_elem = detail_div.find('span', class_='fdi-item')  # fdi-item as per code.txt
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        movie_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        movies.append(movie_info)
        
            return movies
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Error fetching trending movies - {str(e)}', xbmc.LOGERROR)
            return []


    def get_trending_series():
        """Fetch trending TV shows from the home page - using actual HTML structure from code.txt"""
        import requests
        from bs4 import BeautifulSoup
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the home page
            response = client.get("https://flixhq.to/home")
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find the trending TV shows section based on the actual HTML structure from code.txt
            trending_tv_div = soup.find('div', id='trending-tv')
            
            if not trending_tv_div:
                xbmc.log('FlixHQ: Trending TV shows section not found', xbmc.LOGERROR)
                return []
            
            # Find all TV show items in the trending TV shows section based on the actual structure
            tv_items = trending_tv_div.find_all('div', class_='flw-item')
            
            series = []
            for item in tv_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract TV show details based on the actual HTML structure from code.txt
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h3', class_='film-name')  # h3 tag as per code.txt
                    year_elem = detail_div.find('span', class_='fdi-item')  # fdi-item as per code.txt
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        series_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        series.append(series_info)
        
            return series
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Error fetching trending series - {str(e)}', xbmc.LOGERROR)
            return []


    def get_latest_movies():
        """Fetch latest movies from the home page based on the actual HTML structure"""
        import requests
        from bs4 import BeautifulSoup
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the home page
            response = client.get("https://flixhq.to/home")
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find the latest movies section - same structure as trending for latest content
            latest_movies_div = soup.find('div', id='trending-movies')  # Often uses same section for both
            
            if not latest_movies_div:
                xbmc.log('FlixHQ: Latest movies section not found', xbmc.LOGERROR)
                return []
            
            # Find all movie items in the latest movies section
            movie_items = latest_movies_div.find_all('div', class_='flw-item')
            
            movies = []
            for item in movie_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract movie details based on the actual HTML structure
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h3', class_='film-name')  # h3 as per actual structure
                    year_elem = detail_div.find('span', class_='fdi-item')  # fdi-item as per actual structure
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        movie_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        movies.append(movie_info)
        
            return movies
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Error fetching latest movies - {str(e)}', xbmc.LOGERROR)
            return []


    def get_latest_series():
        """Fetch latest TV shows from the home page based on the actual HTML structure"""
        import requests
        from bs4 import BeautifulSoup
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the home page
            response = client.get("https://flixhq.to/home")
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find the latest TV shows section - same structure as trending for latest content
            latest_tv_div = soup.find('div', id='trending-tv')  # Often uses same section for both
            
            if not latest_tv_div:
                xbmc.log('FlixHQ: Latest TV shows section not found', xbmc.LOGERROR)
                return []
            
            # Find all TV show items in the latest TV shows section
            tv_items = latest_tv_div.find_all('div', class_='flw-item')
            
            series = []
            for item in tv_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract TV show details based on the actual HTML structure
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h3', class_='film-name')  # h3 as per actual structure
                    year_elem = detail_div.find('span', class_='fdi-item')  # fdi-item as per actual structure
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        series_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        series.append(series_info)
        
            return series
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Error fetching latest series - {str(e)}', xbmc.LOGERROR)
            return []


    def trending_movies():
        """Display trending movies from actual website structure"""
        try:
            movies = get_trending_movies()
            
            if not movies:
                xbmcgui.Dialog().ok('No Trending Movies', 'No trending movies found at the moment.')
                xbmcplugin.endOfDirectory(handle)
                return
            
            for movie in movies:
                title = movie['title']
                if movie['year']:
                    title = f"{title} ({movie['year']})"
                
                # Create play URL for the movie
                play_url = f"{addon_url}?action=play_movie_by_url&url={urllib.parse.quote_plus(movie['url'])}"
                
                # Add movie to directory
                add_dir(title, play_url, icon_image=movie['img'], is_folder=False)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Trending movies error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load trending movies: {str(e)}')


    def trending_series():
        """Display trending TV shows from actual website structure"""
        try:
            series_list = get_trending_series()
            
            if not series_list:
                xbmcgui.Dialog().ok('No Trending TV Shows', 'No trending TV shows found at the moment.')
                xbmcplugin.endOfDirectory(handle)
                return
            
            for series in series_list:
                title = series['title']
                if series['year']:
                    title = f"{title} ({series['year']})"
                
                # Create URL for the TV show seasons
                series_url_param = f"{addon_url}?action=series_menu_from_url&url={urllib.parse.quote_plus(series['url'])}"
                
                # Add TV show to directory
                add_dir(title, series_url_param, icon_image=series['img'], is_folder=True)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Trending series error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load trending series: {str(e)}')


    def latest_movies():
        """Display latest movies from actual website structure"""
        try:
            movies = get_latest_movies()
            
            if not movies:
                xbmcgui.Dialog().ok('No Latest Movies', 'No latest movies found at the moment.')
                xbmcplugin.endOfDirectory(handle)
                return
            
            for movie in movies:
                title = movie['title']
                if movie['year']:
                    title = f"{title} ({movie['year']})"
                
                # Create play URL for the movie
                play_url = f"{addon_url}?action=play_movie_by_url&url={urllib.parse.quote_plus(movie['url'])}"
                
                # Add movie to directory
                add_dir(title, play_url, icon_image=movie['img'], is_folder=False)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Latest movies error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load latest movies: {str(e)}')


    def latest_series():
        """Display latest TV shows from actual website structure"""
        try:
            series_list = get_latest_series()
            
            if not series_list:
                xbmcgui.Dialog().ok('No Latest TV Shows', 'No latest TV shows found at the moment.')
                xbmcplugin.endOfDirectory(handle)
                return
            
            for series in series_list:
                title = series['title']
                if series['year']:
                    title = f"{title} ({series['year']})"
                
                # Create URL for the TV show seasons
                series_url_param = f"{addon_url}?action=series_menu_from_url&url={urllib.parse.quote_plus(series['url'])}"
                
                # Add TV show to directory
                add_dir(title, series_url_param, icon_image=series['img'], is_folder=True)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Latest series error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load latest series: {str(e)}')


    def get_genres():
        """Fetch genres from the FlixHQ website - using known list from the site"""
        genres = [
            {'url': 'https://flixhq.to/genre/action', 'title': 'Action'},
            {'url': 'https://flixhq.to/genre/action-adventure', 'title': 'Action & Adventure'},
            {'url': 'https://flixhq.to/genre/adventure', 'title': 'Adventure'},
            {'url': 'https://flixhq.to/genre/animation', 'title': 'Animation'},
            {'url': 'https://flixhq.to/genre/biography', 'title': 'Biography'},
            {'url': 'https://flixhq.to/genre/comedy', 'title': 'Comedy'},
            {'url': 'https://flixhq.to/genre/crime', 'title': 'Crime'},
            {'url': 'https://flixhq.to/genre/documentary', 'title': 'Documentary'},
            {'url': 'https://flixhq.to/genre/drama', 'title': 'Drama'},
            {'url': 'https://flixhq.to/genre/family', 'title': 'Family'},
            {'url': 'https://flixhq.to/genre/fantasy', 'title': 'Fantasy'},
            {'url': 'https://flixhq.to/genre/history', 'title': 'History'},
            {'url': 'https://flixhq.to/genre/horror', 'title': 'Horror'},
            {'url': 'https://flixhq.to/genre/kids', 'title': 'Kids'},
            {'url': 'https://flixhq.to/genre/music', 'title': 'Music'},
            {'url': 'https://flixhq.to/genre/mystery', 'title': 'Mystery'},
            {'url': 'https://flixhq.to/genre/news', 'title': 'News'},
            {'url': 'https://flixhq.to/genre/reality', 'title': 'Reality'},
            {'url': 'https://flixhq.to/genre/romance', 'title': 'Romance'},
            {'url': 'https://flixhq.to/genre/sci-fi-fantasy', 'title': 'Sci-Fi & Fantasy'},
            {'url': 'https://flixhq.to/genre/science-fiction', 'title': 'Science Fiction'},
            {'url': 'https://flixhq.to/genre/soap', 'title': 'Soap'},
            {'url': 'https://flixhq.to/genre/talk', 'title': 'Talk'},
            {'url': 'https://flixhq.to/genre/thriller', 'title': 'Thriller'},
            {'url': 'https://flixhq.to/genre/tv-movie', 'title': 'TV Movie'},
            {'url': 'https://flixhq.to/genre/war', 'title': 'War'},
            {'url': 'https://flixhq.to/genre/war-politics', 'title': 'War & Politics'},
            {'url': 'https://flixhq.to/genre/western', 'title': 'Western'}
        ]
        return genres


    def genres_menu():
        """Display genres menu"""
        try:
            genres = get_genres()
            
            for genre in genres:
                # Create URL to browse movies by genre
                browse_url = f"{addon_url}?action=browse_by_genre&genre_url={urllib.parse.quote_plus(genre['url'])}&page=1"
                add_dir(genre['title'], browse_url)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Genres menu error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load genres: {str(e)}')


    def get_countries():
        """Fetch countries from the FlixHQ website - using known list from the site"""
        countries = [
            {'url': 'https://flixhq.to/country/AR', 'title': 'Argentina'},
            {'url': 'https://flixhq.to/country/AU', 'title': 'Australia'},
            {'url': 'https://flixhq.to/country/AT', 'title': 'Austria'},
            {'url': 'https://flixhq.to/country/BE', 'title': 'Belgium'},
            {'url': 'https://flixhq.to/country/BR', 'title': 'Brazil'},
            {'url': 'https://flixhq.to/country/CA', 'title': 'Canada'},
            {'url': 'https://flixhq.to/country/CN', 'title': 'China'},
            {'url': 'https://flixhq.to/country/CZ', 'title': 'Czech Republic'},
            {'url': 'https://flixhq.to/country/DK', 'title': 'Denmark'},
            {'url': 'https://flixhq.to/country/FI', 'title': 'Finland'},
            {'url': 'https://flixhq.to/country/FR', 'title': 'France'},
            {'url': 'https://flixhq.to/country/DE', 'title': 'Germany'},
            {'url': 'https://flixhq.to/country/HK', 'title': 'Hong Kong'},
            {'url': 'https://flixhq.to/country/HU', 'title': 'Hungary'},
            {'url': 'https://flixhq.to/country/IN', 'title': 'India'},
            {'url': 'https://flixhq.to/country/IE', 'title': 'Ireland'},
            {'url': 'https://flixhq.to/country/IL', 'title': 'Israel'},
            {'url': 'https://flixhq.to/country/IT', 'title': 'Italy'},
            {'url': 'https://flixhq.to/country/JP', 'title': 'Japan'},
            {'url': 'https://flixhq.to/country/LU', 'title': 'Luxembourg'},
            {'url': 'https://flixhq.to/country/MX', 'title': 'Mexico'},
            {'url': 'https://flixhq.to/country/NL', 'title': 'Netherlands'},
            {'url': 'https://flixhq.to/country/NZ', 'title': 'New Zealand'},
            {'url': 'https://flixhq.to/country/NO', 'title': 'Norway'},
            {'url': 'https://flixhq.to/country/PL', 'title': 'Poland'},
            {'url': 'https://flixhq.to/country/RO', 'title': 'Romania'},
            {'url': 'https://flixhq.to/country/RU', 'title': 'Russia'},
            {'url': 'https://flixhq.to/country/ZA', 'title': 'South Africa'},
            {'url': 'https://flixhq.to/country/KR', 'title': 'South Korea'},
            {'url': 'https://flixhq.to/country/ES', 'title': 'Spain'},
            {'url': 'https://flixhq.to/country/SE', 'title': 'Sweden'},
            {'url': 'https://flixhq.to/country/CH', 'title': 'Switzerland'},
            {'url': 'https://flixhq.to/country/TW', 'title': 'Taiwan'},
            {'url': 'https://flixhq.to/country/TH', 'title': 'Thailand'},
            {'url': 'https://flixhq.to/country/GB', 'title': 'United Kingdom'},
            {'url': 'https://flixhq.to/country/US', 'title': 'United States of America'}
        ]
        return countries


    def countries_menu():
        """Display countries menu"""
        try:
            countries = get_countries()
            
            for country in countries:
                # Create URL to browse movies by country
                browse_url = f"{addon_url}?action=browse_by_country&country_url={urllib.parse.quote_plus(country['url'])}&page=1"
                add_dir(country['title'], browse_url)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Countries menu error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load countries: {str(e)}')


    def browse_by_genre(genre_url, page_num='1'):
        """Browse content by genre with pagination"""
        import requests
        from bs4 import BeautifulSoup
        import re
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the genre page
            genre_full_url = f"{genre_url}?page={page_num}"
            response = client.get(genre_full_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all movie/tv show items
            content_items = soup.find_all('div', class_='flw-item')
            
            items = []
            for item in content_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract content details
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h2', class_='film-name')
                    year_elem = detail_div.find('span', class_='fdi-item')
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        item_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        items.append(item_info)
            
            # Process the items
            for item in items:
                title = item['title']
                if item['year']:
                    title = f"{title} ({item['year']})"
                
                # Create play URL for the item
                if '/movie/' in item['url']:
                    play_url = f"{addon_url}?action=play_movie_by_url&url={urllib.parse.quote_plus(item['url'])}"
                    add_dir(title, play_url, icon_image=item['img'], is_folder=False)
                else:
                    # For TV shows, go to series menu
                    series_url = f"{addon_url}?action=series_menu_from_url&url={urllib.parse.quote_plus(item['url'])}"
                    add_dir(title, series_url, icon_image=item['img'], is_folder=True)
            
            # Check for pagination to determine if there's a next page
            next_page = None
            current_page = int(page_num) if page_num.isdigit() else 1
            
            # Look for pagination elements to see if there's a next page
            pagination_div = soup.find('div', class_='pre-pagination')
            if pagination_div:
                # Look for links with "Next" or forward arrows
                next_link = pagination_div.find('a', string=re.compile(r'→|Next|\u2192', re.IGNORECASE))
                if next_link:
                    next_url = next_link.get('href', '')
                    match = re.search(r'page=(\d+)', next_url)
                    if match:
                        next_page = match.group(1)
            
            # Add "Next Page" if there are more results
            if next_page:
                next_url = f"{addon_url}?action=browse_by_genre&genre_url={urllib.parse.quote_plus(genre_url)}&page={next_page}"
                add_dir(f'>>> Next Page ({next_page}) >>>', next_url)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Browse by genre error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to browse by genre: {str(e)}')


    def browse_by_country(country_url, page_num='1'):
        """Browse content by country with pagination"""
        import requests
        from bs4 import BeautifulSoup
        import re
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the country page
            country_full_url = f"{country_url}?page={page_num}"
            response = client.get(country_full_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all movie/tv show items
            content_items = soup.find_all('div', class_='flw-item')
            
            items = []
            for item in content_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract content details
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h2', class_='film-name')
                    year_elem = detail_div.find('span', class_='fdi-item')
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        item_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        items.append(item_info)
            
            # Process the items
            for item in items:
                title = item['title']
                if item['year']:
                    title = f"{title} ({item['year']})"
                
                # Create play URL for the item
                if '/movie/' in item['url']:
                    play_url = f"{addon_url}?action=play_movie_by_url&url={urllib.parse.quote_plus(item['url'])}"
                    add_dir(title, play_url, icon_image=item['img'], is_folder=False)
                else:
                    # For TV shows, go to series menu
                    series_url = f"{addon_url}?action=series_menu_from_url&url={urllib.parse.quote_plus(item['url'])}"
                    add_dir(title, series_url, icon_image=item['img'], is_folder=True)
            
            # Check for pagination
            next_page = None
            current_page = int(page_num) if page_num.isdigit() else 1
            
            # Look for pagination elements to see if there's a next page
            pagination_div = soup.find('div', class_='pre-pagination')
            if pagination_div:
                # Look for links with "Next" or forward arrows
                next_link = pagination_div.find('a', string=re.compile(r'→|Next|\u2192', re.IGNORECASE))
                if next_link:
                    next_url = next_link.get('href', '')
                    match = re.search(r'page=(\d+)', next_url)
                    if match:
                        next_page = match.group(1)
            
            # Add "Next Page" if there are more results
            if next_page:
                next_url = f"{addon_url}?action=browse_by_country&country_url={urllib.parse.quote_plus(country_url)}&page={next_page}"
                add_dir(f'>>> Next Page ({next_page}) >>>', next_url)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Browse by country error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to browse by country: {str(e)}')


    def get_movies(page_num='1'):
        """Fetch movies from the movies page"""
        import requests
        from bs4 import BeautifulSoup
        import re
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the movies page
            movies_url = f"https://flixhq.to/movie?page={page_num}"
            response = client.get(movies_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all movie items
            movie_items = soup.find_all('div', class_='flw-item')
            
            movies = []
            for item in movie_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract movie details
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h2', class_='film-name')
                    year_elem = detail_div.find('span', class_='fdi-item')
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        movie_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        movies.append(movie_info)
            
            # Check for pagination
            next_page = None
            current_page = int(page_num) if page_num.isdigit() else 1
            
            # Look for pagination elements to see if there's a next page
            pagination_div = soup.find('div', class_='pre-pagination')
            if pagination_div:
                # Look for links with "Next" or forward arrows
                next_link = pagination_div.find('a', string=re.compile(r'→|Next|\u2192', re.IGNORECASE))
                if next_link:
                    next_url = next_link.get('href', '')
                    match = re.search(r'page=(\d+)', next_url)
                    if match:
                        next_page = match.group(1)
            
            # If we couldn't find next page from the link, we'll assume there might be more
            # based on current page number (a common pattern)
            if next_page is None and len(movie_items) > 0:
                next_page = str(current_page + 1)
            
            return movies, next_page
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Error fetching movies - {str(e)}', xbmc.LOGERROR)
            return [], None


    def movies_menu(page_num='1'):
        """Display movies from the movies page with pagination"""
        try:
            movies, next_page = get_movies(page_num)
            
            for movie in movies:
                title = movie['title']
                if movie['year']:
                    title = f"{title} ({movie['year']})"
                
                # Create play URL for the movie
                play_url = f"{addon_url}?action=play_movie_by_url&url={urllib.parse.quote_plus(movie['url'])}"
                
                # Add movie to directory
                add_dir(title, play_url, icon_image=movie['img'], is_folder=False)
            
            # Add "Next Page" if there are more results
            if next_page:
                next_url = f"{addon_url}?action=movies_menu&page={next_page}"
                add_dir(f'>>> Next Page ({next_page}) >>>', next_url)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Movies menu error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load movies: {str(e)}')


    def get_tvshows(page_num='1'):
        """Fetch TV shows from the TV shows page"""
        import requests
        from bs4 import BeautifulSoup
        import re
        
        headers = {
            "User-Agent": "flix-cli/1.7.11.5",
            "Referer": "https://flixhq.to/",
            "X-Requested-With": "XMLHttpRequest"
        }

        client = requests.Session()
        client.headers.update(headers)
        
        try:
            # Get the TV shows page
            tvshows_url = f"https://flixhq.to/tv-show?page={page_num}"
            response = client.get(tvshows_url)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find all TV show items
            tvshow_items = soup.find_all('div', class_='flw-item')
            
            tvshows = []
            for item in tvshow_items:
                poster_div = item.find('div', class_='film-poster')
                detail_div = item.find('div', class_='film-detail')
                
                if poster_div and detail_div:
                    # Extract TV show details
                    link_elem = poster_div.find('a', class_='film-poster-ahref')
                    title_elem = detail_div.find('h2', class_='film-name')
                    year_elem = detail_div.find('span', class_='fdi-item')
                    img_elem = poster_div.find('img', class_='film-poster-img')
                    
                    if link_elem and title_elem:
                        href = link_elem.get('href', '')
                        title_link = title_elem.find('a')
                        title = title_link.get('title', title_elem.get_text(strip=True)) if title_link else title_elem.get_text(strip=True)
                        
                        # Extract year if available
                        year = year_elem.get_text(strip=True) if year_elem else ""
                        
                        # Extract image source if available
                        img_src = img_elem.get('data-src', '') if img_elem else ''
                        
                        tvshow_info = {
                            'url': f"https://flixhq.to{href}",
                            'title': title,
                            'year': year,
                            'img': img_src
                        }
                        tvshows.append(tvshow_info)
            
            # Check for pagination
            next_page = None
            current_page = int(page_num) if page_num.isdigit() else 1
            
            # Look for pagination elements to see if there's a next page
            pagination_div = soup.find('div', class_='pre-pagination')
            if pagination_div:
                # Look for links with "Next" or forward arrows
                next_link = pagination_div.find('a', string=re.compile(r'→|Next|\u2192', re.IGNORECASE))
                if next_link:
                    next_url = next_link.get('href', '')
                    match = re.search(r'page=(\d+)', next_url)
                    if match:
                        next_page = match.group(1)
            
            # If we couldn't find next page from the link, we'll assume there might be more
            # based on current page number (a common pattern)
            if next_page is None and len(tvshow_items) > 0:
                next_page = str(current_page + 1)
            
            return tvshows, next_page
            
        except Exception as e:
            xbmc.log(f'FlixHQ: Error fetching TV shows - {str(e)}', xbmc.LOGERROR)
            return [], None


    def tvshows_menu(page_num='1'):
        """Display TV shows from the TV shows page with pagination"""
        try:
            tvshows, next_page = get_tvshows(page_num)
            
            for tvshow in tvshows:
                title = tvshow['title']
                if tvshow['year']:
                    title = f"{title} ({tvshow['year']})"
                
                # Create URL for the TV show seasons
                series_url = f"{addon_url}?action=series_menu_from_url&url={urllib.parse.quote_plus(tvshow['url'])}"
                
                # Add TV show to directory
                add_dir(title, series_url, icon_image=tvshow['img'])
            
            # Add "Next Page" if there are more results
            if next_page:
                next_url = f"{addon_url}?action=tvshows_menu&page={next_page}"
                add_dir(f'>>> Next Page ({next_page}) >>>', next_url)
            
            xbmcplugin.endOfDirectory(handle)
            
        except Exception as e:
            xbmc.log(f'FlixHQ: TV shows menu error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to load TV shows: {str(e)}')


    def series_menu_from_url(url):
        """Display seasons for a TV series from a provided URL"""
        import re
        
        try:
            # Extract media ID from the URL
            media_id_match = re.search(r'/tv/[^/]*-(\d+)', url)
            if not media_id_match:
                xbmcgui.Dialog().ok('Error', 'Could not extract media ID from URL')
                return
            
            media_id = media_id_match.group(1)
            
            # Call the function from flix_cli module
            import requests
            
            headers = {
                "User-Agent": "flix-cli/1.7.11.5",
                "Referer": "https://flixhq.to/",
                "X-Requested-With": "XMLHttpRequest"
            }

            client = requests.Session()
            client.headers.update(headers)
            
            FLIXHQ_BASE_URL = "https://flixhq.to"
            FLIXHQ_AJAX_URL = f"{FLIXHQ_BASE_URL}/ajax"
            
            # Get seasons
            seasons_url = f"{FLIXHQ_AJAX_URL}/v2/tv/seasons/{media_id}"
            response = client.get(seasons_url)
            
            if response.status_code == 200:
                season_pattern = re.compile(r'href="[^"]*-(\d+)"[^>]*>([^<]*)</a>')
                matches = season_pattern.findall(response.text)
                
                if matches:
                    for season_id, season_title in matches:
                        season_title_clean = season_title.strip()
                        season_url = f'{addon_url}?action=season_episodes&season_id={season_id}&series_url={urllib.parse.quote_plus(url)}'
                        add_dir(season_title_clean, season_url)
                else:
                    xbmcgui.Dialog().ok('Error', 'No seasons found')
            else:
                xbmcgui.Dialog().ok('Error', f'Failed to get seasons: {response.status_code}')
                
        except Exception as e:
            xbmc.log(f'FlixHQ: Series menu error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to get series: {str(e)}')
        
        xbmcplugin.endOfDirectory(handle)


    def search_menu():
        """Search interface"""
        search_query = xbmcgui.Dialog().input('Enter search query')
        if search_query:
            try:
                # Use the search functionality from the flix_cli module
                # The search_content function was modified to work in Kodi environment
                import requests
                from bs4 import BeautifulSoup
                import re
                from urllib.parse import urljoin
                
                headers = {
                    "User-Agent": "flix-cli/1.7.11.5",
                    "Referer": "https://flixhq.to/",
                    "X-Requested-With": "XMLHttpRequest"
                }

                client = requests.Session()
                client.headers.update(headers)

                FLIXHQ_BASE_URL = "https://flixhq.to"
                FLIXHQ_SEARCH_URL = f"{FLIXHQ_BASE_URL}/search"
                
                try:
                    search_params = search_query.replace(" ", "-")
                    response = client.get(f"{FLIXHQ_SEARCH_URL}/{search_params}")
                    response.raise_for_status()
                    soup = BeautifulSoup(response.text, 'html.parser')
                    items = soup.find_all('div', class_='flw-item')
                    
                    if not items:
                        xbmcgui.Dialog().ok('No Results', f'No results found for: {search_query}')
                        main_menu()
                        return
                    
                    # Prepare list of results for Kodi selection
                    results = []
                    urls = []
                    for i, item in enumerate(items[:10]):  # Limit to first 10 results
                        poster_link = item.find('div', class_='film-poster')
                        detail_section = item.find('div', class_='film-detail')
                        if poster_link and detail_section:
                            link_elem = poster_link.find('a', class_='film-poster-ahref')
                            title_elem = detail_section.find('h2', class_='film-name')
                            if link_elem and title_elem:
                                href = link_elem.get('href', '')
                                title_link = title_elem.find('a')
                                title = title_link.get('title', 'Unknown Title') if title_link else title_elem.get_text(strip=True)
                                info_elem = detail_section.find('div', class_='fd-infor')
                                year = ""
                                content_type_result = ""
                                if info_elem:
                                    spans = info_elem.find_all('span')
                                    if spans:
                                        year = spans[0].text.strip() if spans else ""
                                        if len(spans) > 1:
                                            content_type_result = spans[1].text.strip()
                                display_title = f"{title}"
                                if year:
                                    display_title += f" ({year})"
                                if content_type_result:
                                    display_title += f" [{content_type_result}]"
                                
                                results.append(display_title)
                                urls.append(urljoin(FLIXHQ_BASE_URL, href))
                    
                    if not results:
                        xbmcgui.Dialog().ok('No Results', f'No valid results found for: {search_query}')
                        main_menu()
                        return
                    
                    # Show selection dialog in Kodi
                    selected_index = xbmcgui.Dialog().select('Select Content', results)
                    if selected_index == -1:  # User canceled
                        main_menu()
                        return
                    
                    selected_url = urls[selected_index]
                    
                    # Determine content type
                    if '/movie/' in selected_url:
                        content_type_result = 'movie'
                    elif '/tv/' in selected_url:
                        content_type_result = 'series'
                    else:
                        content_type_result = 'unknown'
                    
                    # Navigate to content details
                    if content_type_result == 'movie':
                        # Create a list item for immediate playback
                        list_item = xbmcgui.ListItem(label='Loading movie...')
                        list_item.setProperty('IsPlayable', 'true')
                        
                        # Resolve the URL immediately
                        xbmcplugin.setResolvedUrl(handle, True, list_item)
                        
                        import time
                        time.sleep(1)
                        
                        # Call the play function directly
                        play_movie_by_url(selected_url)
                        
                    elif content_type_result == 'series':
                        series_url_param = f'{addon_url}?action=series_menu_from_url&url={urllib.parse.quote_plus(selected_url)}'
                        add_dir('Browse Series', series_url_param)
                        xbmcplugin.endOfDirectory(handle)
                    else:
                        xbmcgui.Dialog().ok('Error', 'Unknown content type')
                        main_menu()
                        
                except Exception as e:
                    xbmc.log(f'FlixHQ: Search error - {str(e)}', xbmc.LOGERROR)
                    xbmcgui.Dialog().ok('Error', f'Search failed: {str(e)}')
                    main_menu()
                    
            except Exception as e:
                xbmc.log(f'FlixHQ: Search error - {str(e)}', xbmc.LOGERROR)
                xbmcgui.Dialog().ok('Error', f'Search failed: {str(e)}')
                main_menu()
        else:
            main_menu()


    def series_menu(url):
        """Display seasons for a TV series"""
        import re
        
        try:
            # Extract media ID from the URL
            media_id_match = re.search(r'/tv/[^/]*-(\d+)', url)
            if not media_id_match:
                xbmcgui.Dialog().ok('Error', 'Could not extract media ID from URL')
                return
            
            media_id = media_id_match.group(1)
            
            # Call the function from flix_cli module
            import requests
            
            headers = {
                "User-Agent": "flix-cli/1.7.11.5",
                "Referer": "https://flixhq.to/",
                "X-Requested-With": "XMLHttpRequest"
            }

            client = requests.Session()
            client.headers.update(headers)
            
            FLIXHQ_BASE_URL = "https://flixhq.to"
            FLIXHQ_AJAX_URL = f"{FLIXHQ_BASE_URL}/ajax"
            
            # Get seasons
            seasons_url = f"{FLIXHQ_AJAX_URL}/v2/tv/seasons/{media_id}"
            response = client.get(seasons_url)
            
            if response.status_code == 200:
                season_pattern = re.compile(r'href="[^"]*-(\d+)"[^>]*>([^<]*)</a>')
                matches = season_pattern.findall(response.text)
                
                if matches:
                    for season_id, season_title in matches:
                        season_title_clean = season_title.strip()
                        season_url = f'{addon_url}?action=season_episodes&season_id={season_id}&series_url={urllib.parse.quote_plus(url)}'
                        add_dir(season_title_clean, season_url)
                else:
                    xbmcgui.Dialog().ok('Error', 'No seasons found')
            else:
                xbmcgui.Dialog().ok('Error', f'Failed to get seasons: {response.status_code}')
                
        except Exception as e:
            xbmc.log(f'FlixHQ: Series menu error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to get series: {str(e)}')
        
        xbmcplugin.endOfDirectory(handle)


    def season_episodes(season_id_param, series_url_param):
        """Display episodes for a season - fixed parameter name to avoid scope issues"""
        import re
        
        try:
            # Call the function from flix_cli module
            import requests
            
            headers = {
                "User-Agent": "flix-cli/1.7.11.5",
                "Referer": "https://flixhq.to/",
                "X-Requested-With": "XMLHttpRequest"
            }

            client = requests.Session()
            client.headers.update(headers)
            
            FLIXHQ_BASE_URL = "https://flixhq.to"
            FLIXHQ_AJAX_URL = f"{FLIXHQ_BASE_URL}/ajax"
            
            # Get episodes for the season
            episodes_url = f"{FLIXHQ_AJAX_URL}/v2/season/episodes/{season_id_param}"
            response = client.get(episodes_url)
            
            if response.status_code == 200:
                content = response.text.replace('\n', '').replace('class="nav-item"', '\nclass="nav-item"')
                episode_pattern = re.compile(r'data-id="(\d+)"[^>]*title="([^"]*)"')
                matches = episode_pattern.findall(content)
                
                if matches:
                    # Add option to play multiple episodes
                    play_range_url = f'{addon_url}?action=play_episode_range&season_id={season_id_param}&series_url={urllib.parse.quote_plus(series_url_param)}'
                    add_dir('Play Multiple Episodes...', play_range_url, is_folder=True)
                
                for data_id, episode_title in matches:
                    episode_title_clean = episode_title.strip()
                    
                    # Just play the episode directly (no submenu)
                    play_url = f'{addon_url}?action=play_episode&episode_id={data_id}&series_url={urllib.parse.quote_plus(series_url_param)}'
                    add_dir(episode_title_clean, play_url, is_folder=False)
            else:
                xbmcgui.Dialog().ok('Error', f'Failed to get episodes: {response.status_code}')
                
        except Exception as e:
            xbmc.log(f'FlixHQ: Season episodes error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to get episodes: {str(e)}')
        
        xbmcplugin.endOfDirectory(handle)


    def play_episode_range(season_id, series_url):
        """Allow user to select a range of episodes to play"""
        try:
            import requests
            from bs4 import BeautifulSoup
            import re
            
            headers = {
                "User-Agent": "flix-cli/1.7.11.5",
                "Referer": "https://flixhq.to/",
                "X-Requested-With": "XMLHttpRequest"
            }

            client = requests.Session()
            client.headers.update(headers)
            
            FLIXHQ_BASE_URL = "https://flixhq.to"
            FLIXHQ_AJAX_URL = f"{FLIXHQ_BASE_URL}/ajax"
            
            # Get episodes for the season
            episodes_url = f"{FLIXHQ_AJAX_URL}/v2/season/episodes/{season_id}"
            response = client.get(episodes_url)
            
            if response.status_code == 200:
                content = response.text.replace('\n', '').replace('class="nav-item"', '\nclass="nav-item"')
                episode_pattern = re.compile(r'data-id="(\d+)"[^>]*title="([^"]*)"')
                matches = episode_pattern.findall(content)
                
                if not matches:
                    xbmcgui.Dialog().ok('Error', 'No episodes found for this season')
                    return
                
                # Ask user for first episode
                first_episode_dialog = xbmcgui.Dialog().numeric(0, f'Enter first episode number (1 to {len(matches)})')
                if first_episode_dialog == '':
                    return
                try:
                    first_ep = int(first_episode_dialog)
                    if first_ep < 1 or first_ep > len(matches):
                        xbmcgui.Dialog().ok('Error', 'Invalid episode number')
                        return
                except ValueError:
                    xbmcgui.Dialog().ok('Error', 'Invalid episode number')
                    return
                
                # Ask user for last episode
                last_episode_dialog = xbmcgui.Dialog().numeric(0, f'Enter last episode number ({first_ep} to {len(matches)})')
                if last_episode_dialog == '':
                    return
                try:
                    last_ep = int(last_episode_dialog)
                    if last_ep < first_ep or last_ep > len(matches):
                        xbmcgui.Dialog().ok('Error', 'Invalid episode number')
                        return
                except ValueError:
                    xbmcgui.Dialog().ok('Error', 'Invalid episode number')
                    return
                
                # Create playlist
                playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
                playlist.clear()
                
                # Add episodes to playlist
                for i in range(first_ep - 1, last_ep):  # Convert to 0-indexed
                    data_id, episode_title = matches[i]
                    episode_title_clean = episode_title.strip()
                    
                    # Get server ID for the episode - using imported function
                    server_id = get_episode_servers(data_id)
                    if not server_id:
                        xbmc.log(f'FlixHQ: Could not get server ID for episode {data_id}', xbmc.LOGWARNING)
                        continue
                    
                    # Get embed link using the imported function
                    embed_link = get_embed_link(server_id)
                    if not embed_link:
                        xbmc.log(f'FlixHQ: Could not get embed link for episode {data_id}', xbmc.LOGWARNING)
                        continue
                    
                    # Decrypt the stream URL
                    decrypted_url, subtitles = decrypt_stream_url(embed_link)
                    if decrypted_url:
                        # Create list item for this episode
                        list_item = xbmcgui.ListItem(label=f'{episode_title_clean}')
                        list_item.setPath(decrypted_url)
                        
                        # Add subtitles if available
                        if subtitles and len(subtitles) > 0:
                            list_item.setSubtitles(subtitles)
                        
                        # Add to playlist
                        playlist.add(url=decrypted_url, listitem=list_item)
                        
                        xbmc.log(f'FlixHQ: Added episode {data_id} to playlist', xbmc.LOGDEBUG)
                    else:
                        xbmc.log(f'FlixHQ: Could not decrypt stream URL for episode {data_id}', xbmc.LOGWARNING)
                
                if playlist.size() > 0:
                    # Play the playlist
                    xbmc.Player().play(playlist)
                else:
                    xbmcgui.Dialog().ok('Error', 'No episodes could be added to the playlist')
            else:
                xbmcgui.Dialog().ok('Error', f'Failed to get episodes: {response.status_code}')
        except Exception as e:
            xbmc.log(f'FlixHQ: Play episode range error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to play episode range: {str(e)}')


    def play_movie_by_url(url):
        """Handle movie playback from direct URL - using original approach with proper URL resolution"""
        try:
            import re
            import requests
            
            headers = {
                "User-Agent": "flix-cli/1.7.11.5",
                "Referer": "https://flixhq.to/",
                "X-Requested-With": "XMLHttpRequest"
            }

            client = requests.Session()
            client.headers.update(headers)
            
            FLIXHQ_BASE_URL = "https://flixhq.to"
            FLIXHQ_AJAX_URL = f"{FLIXHQ_BASE_URL}/ajax"
            
            # Extract media ID from the URL
            media_id_match = re.search(r'/movie/[^/]*-(\d+)', url)
            if not media_id_match:
                xbmcgui.Dialog().ok('Error', 'Could not extract media ID from URL')
                return
                
            media_id = media_id_match.group(1)
            
            # Get movie stream - FOLLOWING ORIGINAL APPROACH
            movie_episodes_url = f"{FLIXHQ_AJAX_URL}/movie/episodes/{media_id}"
            response = client.get(movie_episodes_url)
            
            if response.status_code == 200:
                content = response.text.replace('\n', '').replace('class="nav-item"', '\nclass="nav-item"')
                provider_pattern = re.compile(r'href="([^"]*)"[^>]*title="Vidcloud"')
                match = provider_pattern.search(content)
                
                if match:
                    movie_page_url = FLIXHQ_BASE_URL + match.group(1)
                    episode_match = re.search(r'-(\d+)\.(\d+)$', movie_page_url)
                    
                    if episode_match:
                        episode_id = episode_match.group(2)
                        
                        # Get embed link using the imported function from flix_cli module
                        embed_link = get_embed_link(episode_id)
                        if embed_link:
                            # Decrypt the stream URL using the imported function
                            try:
                                decrypted_url, subtitles = decrypt_stream_url(embed_link)
                                if decrypted_url:
                                    # Create a list item for the decrypted URL with proper path
                                    list_item = xbmcgui.ListItem(label='Playing movie...', path=decrypted_url)
                                    
                                    # Add subtitles if available
                                    if subtitles and len(subtitles) > 0:
                                        list_item.setSubtitles(subtitles)
                                    
                                    # Use setResolvedUrl to properly resolve the URL in Kodi
                                    xbmcplugin.setResolvedUrl(handle, True, list_item)
                                    return
                                else:
                                    xbmcgui.Dialog().ok('Error', 'Could not decrypt stream URL')
                                    xbmc.log(f'FlixHQ: Could not decrypt stream URL for movie', xbmc.LOGERROR)
                            except Exception as e:
                                xbmcgui.Dialog().ok('Error', f'Failed to decrypt stream: {str(e)}')
                                xbmc.log(f'FlixHQ: Decrypt error - {str(e)}', xbmc.LOGERROR)
                        else:
                            xbmcgui.Dialog().ok('Error', 'Could not get embed link')
                            xbmc.log(f'FlixHQ: Could not get embed link for movie', xbmc.LOGERROR)
                    else:
                        xbmcgui.Dialog().ok('Error', 'Could not extract episode ID')
                        xbmc.log(f'FlixHQ: Could not extract episode ID from movie page URL', xbmc.LOGERROR)
                else:
                    xbmcgui.Dialog().ok('Error', 'Could not find Vidcloud provider')
                    xbmc.log(f'FlixHQ: Could not find Vidcloud provider for movie', xbmc.LOGERROR)
            else:
                xbmcgui.Dialog().ok('Error', f'Failed to get movie episodes: {response.status_code}')
                xbmc.log(f'FlixHQ: Failed to get movie episodes - status code: {response.status_code}', xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f'FlixHQ: Play movie by URL error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to play movie: {str(e)}')


    def play_movie(url):
        """Handle movie playback - using original approach with proper URL resolution"""
        try:
            import re
            import requests
            
            headers = {
                "User-Agent": "flix-cli/1.7.11.5",
                "Referer": "https://flixhq.to/",
                "X-Requested-With": "XMLHttpRequest"
            }

            client = requests.Session()
            client.headers.update(headers)
            
            FLIXHQ_BASE_URL = "https://flixhq.to"
            FLIXHQ_AJAX_URL = f"{FLIXHQ_BASE_URL}/ajax"
            
            # Extract media ID from the URL
            media_id_match = re.search(r'/movie/[^/]*-(\d+)', url)
            if not media_id_match:
                xbmcgui.Dialog().ok('Error', 'Could not extract media ID from URL')
                return
                
            media_id = media_id_match.group(1)
            
            # Get movie stream - FOLLOWING ORIGINAL APPROACH
            movie_episodes_url = f"{FLIXHQ_AJAX_URL}/movie/episodes/{media_id}"
            response = client.get(movie_episodes_url)
            
            if response.status_code == 200:
                content = response.text.replace('\n', '').replace('class="nav-item"', '\nclass="nav-item"')
                provider_pattern = re.compile(r'href="([^"]*)"[^>]*title="Vidcloud"')
                match = provider_pattern.search(content)
                
                if match:
                    movie_page_url = FLIXHQ_BASE_URL + match.group(1)
                    episode_match = re.search(r'-(\d+)\.(\d+)$', movie_page_url)
                    
                    if episode_match:
                        episode_id = episode_match.group(2)
                        
                        # Get embed link using the imported function from flix_cli module
                        embed_link = get_embed_link(episode_id)
                        if embed_link:
                            # Decrypt the stream URL using the imported function
                            try:
                                decrypted_url, subtitles = decrypt_stream_url(embed_link)
                                if decrypted_url:
                                    # Create a list item for the decrypted URL with proper path
                                    list_item = xbmcgui.ListItem(label='Playing movie...', path=decrypted_url)
                                    
                                    # Add subtitles if available
                                    if subtitles and len(subtitles) > 0:
                                        list_item.setSubtitles(subtitles)
                                    
                                    # Use setResolvedUrl to properly resolve the URL in Kodi
                                    xbmcplugin.setResolvedUrl(handle, True, list_item)
                                    return
                                else:
                                    xbmcgui.Dialog().ok('Error', 'Could not decrypt stream URL')
                                    xbmc.log(f'FlixHQ: Could not decrypt stream URL for movie', xbmc.LOGERROR)
                            except Exception as e:
                                xbmcgui.Dialog().ok('Error', f'Failed to decrypt stream: {str(e)}')
                                xbmc.log(f'FlixHQ: Decrypt error - {str(e)}', xbmc.LOGERROR)
                        else:
                            xbmcgui.Dialog().ok('Error', 'Could not get embed link')
                            xbmc.log(f'FlixHQ: Could not get embed link for movie', xbmc.LOGERROR)
                    else:
                        xbmcgui.Dialog().ok('Error', 'Could not extract episode ID')
                        xbmc.log(f'FlixHQ: Could not extract episode ID from movie page URL', xbmc.LOGERROR)
                else:
                    xbmcgui.Dialog().ok('Error', 'Could not find Vidcloud provider')
                    xbmc.log(f'FlixHQ: Could not find Vidcloud provider for movie', xbmc.LOGERROR)
            else:
                xbmcgui.Dialog().ok('Error', f'Failed to get movie episodes: {response.status_code}')
                xbmc.log(f'FlixHQ: Failed to get movie episodes - status code: {response.status_code}', xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f'FlixHQ: Play movie error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Playback Error', f'Failed to play movie: {str(e)}')


    def play_episode(episode_id, series_url):
        """Handle single episode playback - using original approach with proper URL resolution"""
        try:
            # Get server ID for the episode - using imported function
            server_id = get_episode_servers(episode_id)
            if not server_id:
                xbmcgui.Dialog().ok('Error', 'Could not get server ID for episode')
                return
            
            # Get embed link - using imported function
            embed_link = get_embed_link(server_id)
            if not embed_link:
                xbmcgui.Dialog().ok('Error', 'Could not get embed link')
                return
            
            # Decrypt the stream URL
            decrypted_url, subtitles = decrypt_stream_url(embed_link)
            if decrypted_url:
                # Create a list item for the decrypted URL with proper path
                list_item = xbmcgui.ListItem(label='Playing episode...', path=decrypted_url)
                
                # Add subtitles if available
                if subtitles and len(subtitles) > 0:
                    list_item.setSubtitles(subtitles)
                
                # Use setResolvedUrl to properly resolve the URL in Kodi
                xbmcplugin.setResolvedUrl(handle, True, list_item)
                return
            else:
                xbmcgui.Dialog().ok('Error', 'Could not decrypt stream URL')
                xbmc.log(f'FlixHQ: Could not decrypt stream URL for episode', xbmc.LOGERROR)
        except Exception as e:
            xbmc.log(f'FlixHQ: Play episode error - {str(e)}', xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Error', f'Failed to play episode: {str(e)}')


    # Route based on action - FIXED to properly handle all parameters
    if action == 'main_menu':
        main_menu()
    elif action == 'trending_menu':
        trending_menu()
    elif action == 'trending_movies':
        trending_movies()
    elif action == 'trending_series':
        trending_series()
    elif action == 'latest_menu':
        latest_menu()
    elif action == 'latest_movies':
        latest_movies()
    elif action == 'latest_series':
        latest_series()
    elif action == 'movies_menu':
        movies_menu(page)
    elif action == 'tvshows_menu':
        tvshows_menu(page)
    elif action == 'genres_menu':
        genres_menu()
    elif action == 'countries_menu':
        countries_menu()
    elif action == 'browse_by_genre':
        genre_url = params.get('genre_url', '')
        if genre_url:
            browse_by_genre(genre_url, page)
        else:
            main_menu()
    elif action == 'browse_by_country':
        country_url = params.get('country_url', '')
        if country_url:
            browse_by_country(country_url, page)
        else:
            main_menu()
    elif action == 'search':
        search_menu()
    elif action == 'series_menu':
        series_menu(url)
    elif action == 'series_menu_from_url':
        if url:
            series_menu_from_url(url)
        else:
            main_menu()
    elif action == 'season_episodes':
        # FIXED: Extract the parameters properly to avoid scope issues
        season_id_param = params.get('season_id', '')
        series_url_param = params.get('series_url', '')
        if season_id_param and series_url_param:
            season_episodes(season_id_param, series_url_param)
        else:
            xbmcgui.Dialog().ok('Error', 'Missing season ID or series URL')
            main_menu()
    elif action == 'play_episode_range':
        season_id_param = params.get('season_id', '')
        series_url_param = params.get('series_url', '')
        if season_id_param and series_url_param:
            play_episode_range(season_id_param, series_url_param)
        else:
            xbmcgui.Dialog().ok('Error', 'Missing season ID or series URL')
            main_menu()
    elif action == 'play_movie':
        if url:
            try:
                play_movie(url)
            except Exception as e:
                xbmc.log(f'FlixHQ: Play movie error - {str(e)}', xbmc.LOGERROR)
                xbmcgui.Dialog().ok('Playback Error', f'Failed to play movie: {str(e)}')
        else:
            main_menu()
    elif action == 'play_movie_by_url':
        if url:
            try:
                play_movie_by_url(url)
            except Exception as e:
                xbmc.log(f'FlixHQ: Play movie by URL error - {str(e)}', xbmc.LOGERROR)
                xbmcgui.Dialog().ok('Playback Error', f'Failed to play movie: {str(e)}')
        else:
            main_menu()
    elif action == 'play_episode':
        episode_id_param = params.get('episode_id', '')
        series_url_param = params.get('series_url', '')
        if episode_id_param and series_url_param:
            try:
                play_episode(episode_id_param, series_url_param)
            except Exception as e:
                xbmc.log(f'FlixHQ: Play episode error - {str(e)}', xbmc.LOGERROR)
                xbmcgui.Dialog().ok('Playback Error', f'Failed to play episode: {str(e)}')
        else:
            xbmcgui.Dialog().ok('Error', 'Missing episode ID or series URL')
            main_menu()
    else:
        main_menu()